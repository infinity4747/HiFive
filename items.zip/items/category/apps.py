from django.apps import AppConfig


class CategoryConfig(AppConfig):
    name = 'category'

class ProductConfig(AppConfig):
    name = 'product'
